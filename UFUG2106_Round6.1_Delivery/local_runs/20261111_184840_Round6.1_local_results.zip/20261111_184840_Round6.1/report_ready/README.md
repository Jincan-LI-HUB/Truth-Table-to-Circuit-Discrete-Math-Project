# Round 6.1 report_ready
This folder belongs in `local_runs/YYYYMMDD_HHMMSS_Round6.1/report_ready/`.
Keep raw official reports, netlists, independent verification, source hashes and
compiler environment in the parent local-run folder. No sudo/network/zip needed.
