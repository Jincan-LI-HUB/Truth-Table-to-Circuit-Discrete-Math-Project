# Round 5 report_ready

The local comparison is `local_reproduction_report.md`. The algorithm design
and proofs are in `mathematical_design.md`, and `reference_experiment.md` is
**historical container evidence** distinct from this new local run.

The actual official CSV, output circuits, compiler/source fingerprints,
independent checker log and stage profiler logs are retained one directory up.
Keep the frozen Round 4.1 source and historical logs unchanged.
